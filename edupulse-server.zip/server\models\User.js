const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true, minlength: 6 },
  role: { type: String, enum: ['admin', 'hod', 'faculty', 'student', 'parent'], required: true },
  avatar: { type: String, default: '' },
  phone: { type: String, default: '' },
  department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
  // For parent role
  linkedStudents: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  // For student role
  parentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  rollNumber: { type: String, default: '' },
  class: { type: String, default: '' },
  year: { type: Number, default: 1 },
  semester: { type: Number, default: 1 },
  isActive: { type: Boolean, default: true },
}, { timestamps: true });

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.comparePassword = async function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
