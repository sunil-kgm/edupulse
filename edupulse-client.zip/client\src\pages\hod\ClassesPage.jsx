import { useState } from 'react';
import { FiPlus, FiUsers, FiBook } from 'react-icons/fi';

const DEMO_CLASSES = [
  { _id: 'c1', name: 'I CSE - A', year: 1, semester: 1, students: 60, classTeacher: 'Dr. Suresh Babu', courses: ['Engineering Mathematics', 'Programming in C', 'Physics', 'English'], strength: 60, attendance: 88 },
  { _id: 'c2', name: 'I CSE - B', year: 1, semester: 1, students: 58, classTeacher: 'Mrs. Lakshmi Devi', courses: ['Engineering Mathematics', 'Programming in C', 'Physics', 'English'], strength: 58, attendance: 85 },
  { _id: 'c3', name: 'II CSE - A', year: 2, semester: 3, students: 55, classTeacher: 'Prof. Rajesh Iyer', courses: ['Data Structures', 'Digital Electronics', 'Discrete Math'], strength: 55, attendance: 82 },
  { _id: 'c4', name: 'III CSE - A', year: 3, semester: 5, students: 52, classTeacher: 'Dr. Priya Nair', courses: ['Database Management', 'Operating Systems', 'Computer Networks', 'Data Structures'], strength: 52, attendance: 79 },
  { _id: 'c5', name: 'III CSE - B', year: 3, semester: 5, students: 50, classTeacher: 'Dr. Anitha Krishnan', courses: ['Database Management', 'Operating Systems', 'Computer Networks'], strength: 50, attendance: 76 },
  { _id: 'c6', name: 'IV CSE - A', year: 4, semester: 7, students: 48, classTeacher: 'Dr. Suresh Babu', courses: ['Machine Learning', 'Cloud Computing', 'Project'], strength: 48, attendance: 83 },
];

export default function ClassesPage() {
  const [selected, setSelected] = useState(null);

  if (selected) {
    const cls = DEMO_CLASSES.find(c => c._id === selected);
    return (
      <div className="animate-fade-in">
        <button className="btn btn-secondary btn-sm" onClick={() => setSelected(null)} style={{ marginBottom: '20px' }}>← Back to Classes</button>
        <div className="page-header">
          <div className="page-title">{cls.name}</div>
          <div className="page-subtitle">Year {cls.year} · Semester {cls.semester} · Class Teacher: {cls.classTeacher}</div>
        </div>
        <div className="grid-2">
          <div className="card">
            <div className="card-title" style={{ marginBottom: '16px' }}>Class Info</div>
            {[
              { label: 'Class Name', value: cls.name },
              { label: 'Year', value: `Year ${cls.year}` },
              { label: 'Semester', value: `Semester ${cls.semester}` },
              { label: 'Class Teacher', value: cls.classTeacher },
              { label: 'Total Students', value: cls.students },
              { label: 'Avg Attendance', value: `${cls.attendance}%` },
            ].map(f => (
              <div key={f.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--color-border-light)' }}>
                <span style={{ fontSize: '13px', color: 'var(--color-text-muted)' }}>{f.label}</span>
                <span style={{ fontSize: '14px', fontWeight: 600 }}>{f.value}</span>
              </div>
            ))}
          </div>
          <div className="card">
            <div className="card-title" style={{ marginBottom: '16px' }}>Courses Offered</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {cls.courses.map((c, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '12px', background: 'var(--color-bg-secondary)', borderRadius: '10px', border: '1px solid var(--color-border)' }}>
                  <span style={{ fontSize: '18px' }}>📚</span>
                  <span style={{ fontSize: '14px', fontWeight: 600 }}>{c}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="page-header">
        <div className="page-header-row">
          <div>
            <div className="page-title">Classes</div>
            <div className="page-subtitle">{DEMO_CLASSES.length} classes in CSE Department</div>
          </div>
          <button className="btn btn-primary"><FiPlus size={14} /> Add Class</button>
        </div>
      </div>

      <div className="grid-2">
        {DEMO_CLASSES.map(cls => (
          <div key={cls._id} className="card" style={{ cursor: 'pointer', transition: 'all 0.2s' }}
            onClick={() => setSelected(cls._id)}
            onMouseEnter={e => e.currentTarget.style.boxShadow = 'var(--shadow-lg)'}
            onMouseLeave={e => e.currentTarget.style.boxShadow = ''}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
              <div>
                <div style={{ fontSize: '18px', fontWeight: 800, fontFamily: "'Space Grotesk',sans-serif" }}>{cls.name}</div>
                <div style={{ fontSize: '13px', color: 'var(--color-text-muted)' }}>Year {cls.year} · Semester {cls.semester}</div>
              </div>
              <span className={`badge ${cls.attendance >= 80 ? 'badge-success' : 'badge-warning'}`}>{cls.attendance}% Att.</span>
            </div>

            <div style={{ display: 'flex', gap: '20px', marginBottom: '16px' }}>
              <div>
                <div style={{ fontSize: '22px', fontWeight: 800, color: '#3b82f6', fontFamily: "'Space Grotesk',sans-serif" }}>{cls.students}</div>
                <div style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>Students</div>
              </div>
              <div>
                <div style={{ fontSize: '22px', fontWeight: 800, color: '#7c3aed', fontFamily: "'Space Grotesk',sans-serif" }}>{cls.courses.length}</div>
                <div style={{ fontSize: '11px', color: 'var(--color-text-muted)' }}>Courses</div>
              </div>
            </div>

            <div style={{ marginBottom: '12px' }}>
              <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginBottom: '4px' }}>Attendance</div>
              <div className="progress-bar-container">
                <div className="progress-bar-fill" style={{ width: `${cls.attendance}%`, background: cls.attendance >= 80 ? 'var(--color-primary)' : '#f97316' }} />
              </div>
            </div>

            <div style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>
              👨‍🏫 {cls.classTeacher}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
