import { useState } from 'react';
import { DEMO_RECOVERY_PATH, DEMO_RISK_FLAG } from '../../data/mockData';
import { FiCheck, FiClock, FiCircle, FiAward, FiTrendingUp } from 'react-icons/fi';

export default function RecoveryPage() {
  const [recovery, setRecovery] = useState(DEMO_RECOVERY_PATH);
  const risk = DEMO_RISK_FLAG;

  const completedCount = recovery.milestones.filter(m => m.status === 'completed').length;
  const total = recovery.milestones.length;

  const advanceMilestone = () => {
    setRecovery(prev => {
      const updated = { ...prev };
      const milestones = prev.milestones.map(m => ({ ...m }));
      const currentIdx = milestones.findIndex(m => m.status === 'current');
      if (currentIdx !== -1) {
        milestones[currentIdx].status = 'completed';
        milestones[currentIdx].completedAt = new Date().toISOString().split('T')[0];
        if (currentIdx + 1 < milestones.length) {
          milestones[currentIdx + 1].status = 'current';
        }
      }
      const done = milestones.filter(m => m.status === 'completed').length;
      return { ...updated, milestones, progressPercent: Math.round((done / milestones.length) * 100) };
    });
  };

  const statusIcon = (status) => {
    if (status === 'completed') return <FiCheck size={12} color="white" />;
    if (status === 'current') return <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--color-primary)' }} />;
    return null;
  };

  const dotStyle = (status) => ({
    width: 26, height: 26, borderRadius: '50%', flexShrink: 0,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    background: status === 'completed' ? 'var(--color-primary)' : status === 'current' ? 'white' : 'var(--color-bg-secondary)',
    border: `2.5px solid ${status === 'completed' ? 'var(--color-primary)' : status === 'current' ? 'var(--color-primary)' : 'var(--color-border)'}`,
    boxShadow: status === 'current' ? '0 0 0 5px var(--color-primary-lighter)' : 'none',
  });

  return (
    <div className="animate-fade-in" style={{ maxWidth: '800px' }}>
      <div className="page-header">
        <div className="page-title">Your Recovery Journey</div>
        <div className="page-subtitle">Follow these milestones to get back on track</div>
      </div>

      {/* Risk Context */}
      <div style={{
        background: 'linear-gradient(135deg, #fff5f5, #fef2f2)',
        border: '1.5px solid #fecaca', borderRadius: '16px',
        padding: '20px 24px', marginBottom: '24px',
        display: 'flex', alignItems: 'center', gap: '20px', flexWrap: 'wrap'
      }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: '15px', color: '#ef4444', marginBottom: '6px' }}>
            ⚠️ High Risk — Recovery in Progress
          </div>
          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            {risk.reasons.map(r => (
              <span key={r} style={{ fontSize: '12px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '99px', padding: '3px 10px', color: '#ef4444', fontWeight: 600 }}>
                {r}
              </span>
            ))}
          </div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: '32px', fontWeight: 800, color: 'var(--color-primary)', fontFamily: "'Space Grotesk', sans-serif" }}>
            {recovery.progressPercent}%
          </div>
          <div style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>Complete</div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="card" style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
          <div style={{ fontWeight: 700 }}>Overall Progress</div>
          <div style={{ fontSize: '14px', fontWeight: 700, color: 'var(--color-primary)' }}>
            {completedCount} / {total} milestones
          </div>
        </div>
        <div className="progress-bar-container" style={{ height: '12px' }}>
          <div className="progress-bar-fill" style={{ width: `${recovery.progressPercent}%`, height: '100%' }} />
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '6px' }}>
          <span>Started</span>
          <span>Recovery Complete</span>
        </div>
      </div>

      {/* Timeline */}
      <div className="card">
        <div className="card-title" style={{ marginBottom: '24px' }}>
          <FiTrendingUp size={16} style={{ marginRight: '8px', color: 'var(--color-primary)' }} />
          Milestone Tracker
        </div>

        <div style={{ position: 'relative', paddingLeft: '36px' }}>
          {/* Vertical line */}
          <div style={{
            position: 'absolute', left: '12px', top: '16px',
            bottom: '16px', width: '2px',
            background: 'linear-gradient(to bottom, var(--color-primary) 33%, var(--color-border) 33%)'
          }} />

          {recovery.milestones.map((m, i) => (
            <div key={m._id} style={{ position: 'relative', paddingBottom: i < recovery.milestones.length - 1 ? '28px' : '0' }}>
              {/* Dot */}
              <div style={{ position: 'absolute', left: '-36px', top: '4px', ...dotStyle(m.status) }}>
                {statusIcon(m.status)}
              </div>

              {/* Card */}
              <div style={{
                background: m.status === 'completed' ? '#f0fdf4' : m.status === 'current' ? 'white' : 'var(--color-bg-secondary)',
                border: `1.5px solid ${m.status === 'completed' ? '#bbf7d0' : m.status === 'current' ? 'var(--color-primary)' : 'var(--color-border)'}`,
                borderRadius: '14px', padding: '16px 20px',
                boxShadow: m.status === 'current' ? 'var(--shadow-glow)' : 'none',
                transition: 'all 0.2s',
              }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '12px' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                      <span style={{ fontSize: '13px', fontWeight: 700, color: 'var(--color-text-muted)', letterSpacing: '0.5px' }}>
                        STEP {m.order}
                      </span>
                      <span className={`badge ${m.status === 'completed' ? 'badge-success' : m.status === 'current' ? 'badge-info' : 'badge-neutral'}`}>
                        {m.status === 'completed' ? '✓ Completed' : m.status === 'current' ? '● In Progress' : '○ Pending'}
                      </span>
                    </div>
                    <div style={{ fontSize: '15px', fontWeight: 700, marginBottom: '4px' }}>{m.title}</div>
                    <div style={{ fontSize: '13px', color: 'var(--color-text-secondary)' }}>{m.description}</div>
                    {m.completedAt && (
                      <div style={{ fontSize: '11px', color: 'var(--color-success)', marginTop: '6px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <FiCheck size={10} /> Completed on {m.completedAt}
                      </div>
                    )}
                    {m.dueDate && m.status !== 'completed' && (
                      <div style={{ fontSize: '11px', color: m.status === 'current' ? 'var(--color-primary)' : 'var(--color-text-muted)', marginTop: '6px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <FiClock size={10} /> Due: {m.dueDate}
                      </div>
                    )}
                  </div>
                </div>

                {/* Action button for current milestone */}
                {m.status === 'current' && (
                  <div style={{ marginTop: '14px', paddingTop: '14px', borderTop: '1px solid var(--color-border)' }}>
                    <button className="btn btn-primary btn-sm" onClick={advanceMilestone}
                      id={`complete-milestone-${m._id}`}>
                      Mark as Complete ✓
                    </button>
                    <span style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginLeft: '12px' }}>
                      This will advance to the next step
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Completion message */}
        {recovery.progressPercent === 100 && (
          <div style={{ textAlign: 'center', marginTop: '32px', padding: '32px', background: 'var(--color-success-bg)', borderRadius: '16px', border: '2px solid #bbf7d0' }}>
            <div style={{ fontSize: '48px', marginBottom: '16px' }}>🎉</div>
            <div style={{ fontSize: '22px', fontWeight: 700, color: 'var(--color-success)', marginBottom: '8px' }}>Recovery Complete!</div>
            <div style={{ fontSize: '14px', color: 'var(--color-text-secondary)' }}>
              You've completed all milestones. Your risk status will be re-evaluated by your faculty.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
