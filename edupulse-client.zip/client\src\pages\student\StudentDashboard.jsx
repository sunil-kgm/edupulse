import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  DEMO_ASSIGNMENTS, DEMO_ATTENDANCE, DEMO_RISK_FLAG, DEMO_RECOVERY_PATH,
  DEMO_RESOURCES, DEMO_PERFORMANCE_CHART, DEMO_QUIZZES
} from '../../data/mockData';
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend
} from 'recharts';
import { FiTrendingUp, FiCalendar, FiFileText, FiAlertTriangle, FiArrowRight, FiCheck, FiClock, FiBookOpen, FiStar, FiExternalLink } from 'react-icons/fi';

function StatCard({ icon, label, value, sub, valueColor, trend }) {
  return (
    <div className="stat-card">
      <div className="stat-card-top">
        <div className="stat-card-icon" style={{ background: valueColor + '15' }}>
          {icon}
        </div>
      </div>
      <div className="stat-card-value" style={{ color: valueColor || 'var(--color-text-primary)' }}>{value}</div>
      <div className="stat-card-label">{label}</div>
      {sub && <div className="stat-card-change neutral">{sub}</div>}
      {trend && (
        <div className={`stat-card-change ${trend.dir}`}>
          {trend.dir === 'positive' ? '↑' : '↓'} {trend.text}
        </div>
      )}
    </div>
  );
}

function RiskBadge({ level }) {
  const cfg = {
    high: { class: 'badge-high-risk', label: 'High Risk', icon: '🔴' },
    medium: { class: 'badge-medium-risk', label: 'Medium Risk', icon: '🟠' },
    low: { class: 'badge-low-risk', label: 'Low Risk', icon: '🟡' },
    none: { class: 'badge-success', label: 'No Risk', icon: '🟢' },
  };
  const c = cfg[level] || cfg.none;
  return <span className={`badge ${c.class}`}>{c.icon} {c.label}</span>;
}

function CircularProgress({ percent, size = 100, strokeWidth = 8, color = '#16a34a' }) {
  const r = (size - strokeWidth) / 2;
  const circ = 2 * Math.PI * r;
  const dash = (percent / 100) * circ;

  return (
    <div className="circular-progress" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#f0f2f6" strokeWidth={strokeWidth} />
        <circle
          cx={size/2} cy={size/2} r={r}
          fill="none" stroke={color} strokeWidth={strokeWidth}
          strokeDasharray={`${dash} ${circ}`}
          strokeLinecap="round"
          style={{ transition: 'stroke-dasharray 1s ease' }}
        />
      </svg>
      <div className="circular-progress-text">
        <div style={{ fontSize: size * 0.18, fontWeight: 700, fontFamily: "'Space Grotesk', sans-serif", color }}>{percent}%</div>
        <div style={{ fontSize: size * 0.1, color: 'var(--color-text-muted)' }}>Attendance</div>
      </div>
    </div>
  );
}

function MilestoneTimeline({ milestones }) {
  return (
    <div className="timeline">
      {milestones.map((m, i) => (
        <div key={m._id} className="timeline-item">
          <div className={`timeline-dot ${m.status}`}>
            {m.status === 'completed' && <FiCheck size={10} color="white" />}
            {m.status === 'current' && <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--color-primary)' }} />}
          </div>
          <div className={`timeline-content ${m.status}`}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div className="timeline-title">{m.title}</div>
              <span className={`badge ${m.status === 'completed' ? 'badge-success' : m.status === 'current' ? 'badge-info' : 'badge-neutral'}`}>
                {m.status === 'completed' ? 'Done' : m.status === 'current' ? 'In Progress' : 'Pending'}
              </span>
            </div>
            <div className="timeline-desc">{m.description}</div>
            {m.dueDate && m.status !== 'completed' && (
              <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginTop: '6px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                <FiClock size={10} /> Due: {m.dueDate}
              </div>
            )}
            {m.completedAt && (
              <div style={{ fontSize: '11px', color: 'var(--color-success)', marginTop: '6px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                <FiCheck size={10} /> Completed {m.completedAt}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

const typeIconMap = { video: '🎬', pdf: '📄', article: '📖', practice: '✏️', quiz_set: '📝' };

export default function StudentDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const attendance = DEMO_ATTENDANCE;
  const risk = DEMO_RISK_FLAG;
  const recovery = DEMO_RECOVERY_PATH;
  const assignments = DEMO_ASSIGNMENTS;
  const resources = DEMO_RESOURCES;

  const overallPerformance = 44;
  const assignmentCompletion = '1 / 4';

  return (
    <div className="animate-fade-in">
      {/* Greeting Header */}
      <div className="page-header">
        <div className="page-header-row">
          <div>
            <div className="page-title">
              {new Date().getHours() < 12 ? 'Good morning' : 'Good afternoon'}, {user?.name?.split(' ')[0]}! 👋
            </div>
            <div className="page-subtitle">Here's your academic snapshot for today, {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</div>
          </div>
          <RiskBadge level={risk.level} />
        </div>
      </div>

      {/* Stat Cards */}
      <div className="stats-grid">
        <StatCard
          icon={<FiTrendingUp size={20} color="#ef4444" />}
          label="Overall Performance"
          value={`${overallPerformance}%`}
          valueColor="#ef4444"
          sub="Below threshold (50%)"
        />
        <StatCard
          icon={<FiCalendar size={20} color="#f97316" />}
          label="Attendance"
          value={`${attendance.overall}%`}
          valueColor="#f97316"
          sub="Below required 75%"
        />
        <StatCard
          icon={<FiFileText size={20} color="#3b82f6" />}
          label="Assignments"
          value={assignmentCompletion}
          valueColor="#3b82f6"
          sub="3 pending or overdue"
        />
        <StatCard
          icon={<FiAlertTriangle size={20} color="#ef4444" />}
          label="Risk Status"
          value="High"
          valueColor="#ef4444"
          sub="Since 20 Sep 2026"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid-2-1" style={{ marginBottom: 'var(--space-6)' }}>
        {/* Performance Chart */}
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Academic Performance</div>
              <div className="card-subtitle">Quiz & Assignment scores over time</div>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={DEMO_PERFORMANCE_CHART}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} domain={[0, 100]} />
              <Tooltip
                contentStyle={{ borderRadius: '10px', border: '1px solid var(--color-border)', fontSize: '13px' }}
              />
              <Legend />
              <Line type="monotone" dataKey="quizScore" stroke="#16a34a" strokeWidth={2.5} dot={{ fill: '#16a34a', r: 4 }} name="Quiz" />
              <Line type="monotone" dataKey="assignmentScore" stroke="#3b82f6" strokeWidth={2.5} dot={{ fill: '#3b82f6', r: 4 }} name="Assignments" />
              <Line type="monotone" dataKey="overall" stroke="#f97316" strokeWidth={2} strokeDasharray="5 5" dot={{ fill: '#f97316', r: 3 }} name="Overall" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Attendance Card */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">Attendance</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '20px' }}>
            <CircularProgress
              percent={attendance.overall}
              size={120}
              strokeWidth={10}
              color={attendance.overall >= 75 ? '#16a34a' : attendance.overall >= 60 ? '#f97316' : '#ef4444'}
            />
            <div style={{ width: '100%' }}>
              {[
                { label: 'Present', value: attendance.present, color: '#16a34a' },
                { label: 'Absent', value: attendance.absent, color: '#ef4444' },
                { label: 'Total', value: attendance.total, color: 'var(--color-text-secondary)' },
              ].map(s => (
                <div key={s.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid var(--color-border-light)' }}>
                  <span style={{ fontSize: '13px', color: 'var(--color-text-muted)' }}>{s.label}</span>
                  <span style={{ fontSize: '14px', fontWeight: 700, color: s.color }}>{s.value}</span>
                </div>
              ))}
            </div>
            <Link to="/attendance" className="btn btn-secondary btn-sm" style={{ width: '100%' }}>
              View Details <FiArrowRight size={12} />
            </Link>
          </div>
        </div>
      </div>

      {/* Risk Flag Alert */}
      {risk && (
        <div style={{
          background: '#fff5f5',
          border: '1.5px solid var(--color-high-risk-border)',
          borderRadius: 'var(--radius-xl)',
          padding: 'var(--space-5) var(--space-6)',
          marginBottom: 'var(--space-6)',
          display: 'flex',
          alignItems: 'flex-start',
          gap: 'var(--space-4)',
        }}>
          <div style={{
            width: 44, height: 44, borderRadius: '12px',
            background: '#fef2f2', border: '1px solid #fecaca',
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
          }}>
            <FiAlertTriangle size={20} color="#ef4444" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
              <span style={{ fontSize: '15px', fontWeight: 700, color: '#ef4444' }}>High Risk Detected</span>
              <span className="badge badge-high-risk">High</span>
            </div>
            <div style={{ fontSize: '13px', color: 'var(--color-text-secondary)', marginBottom: '10px' }}>
              Your academic performance has been flagged. The following concerns were identified:
            </div>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
              {risk.reasons.map(r => (
                <span key={r} style={{
                  background: '#fef2f2', border: '1px solid #fecaca',
                  borderRadius: '99px', padding: '4px 12px', fontSize: '12px', color: '#ef4444', fontWeight: 600,
                }}>• {r}</span>
              ))}
            </div>
          </div>
          <Link to="/recovery" className="btn btn-danger btn-sm" style={{ flexShrink: 0 }}>
            Recovery Path
          </Link>
        </div>
      )}

      {/* Academic Backlog + Recovery */}
      <div className="grid-2" style={{ marginBottom: 'var(--space-6)' }}>
        {/* Pending Work */}
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Pending Academic Work</div>
              <div className="card-subtitle">Backlogs requiring attention</div>
            </div>
            <Link to="/assignments" className="btn btn-secondary btn-sm">View All</Link>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
            {assignments.filter(a => a.status !== 'submitted').map(a => {
              const statusCfg = {
                incomplete: { class: 'badge-warning', label: 'Incomplete' },
                overdue: { class: 'badge-error', label: 'Overdue' },
                pending: { class: 'badge-info', label: 'Pending' },
              };
              const sc = statusCfg[a.status] || { class: 'badge-neutral', label: a.status };
              return (
                <div key={a._id} style={{
                  padding: 'var(--space-4)',
                  background: 'var(--color-bg-secondary)',
                  borderRadius: 'var(--radius-lg)',
                  border: '1px solid var(--color-border)',
                }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '6px' }}>
                    <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--color-text-primary)' }}>{a.title}</div>
                    <span className={`badge ${sc.class}`}>{sc.label}</span>
                  </div>
                  <div style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>{a.course.name}</div>
                  <div style={{ fontSize: '11px', color: a.status === 'overdue' ? 'var(--color-error)' : 'var(--color-text-muted)', marginTop: '4px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <FiClock size={10} /> Due: {a.dueDate}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recovery Path Preview */}
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Recovery Path</div>
              <div className="card-subtitle">{recovery.progressPercent}% complete</div>
            </div>
            <Link to="/recovery" className="btn btn-secondary btn-sm">View Full</Link>
          </div>
          <div style={{ marginBottom: 'var(--space-4)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: 'var(--color-text-muted)', marginBottom: '6px' }}>
              <span>Progress</span>
              <span style={{ fontWeight: 700, color: 'var(--color-primary)' }}>{recovery.progressPercent}%</span>
            </div>
            <div className="progress-bar-container">
              <div className="progress-bar-fill" style={{ width: `${recovery.progressPercent}%` }} />
            </div>
          </div>
          <MilestoneTimeline milestones={recovery.milestones.slice(0, 4)} />
        </div>
      </div>

      {/* Recommended Resources */}
      <div className="card">
        <div className="card-header">
          <div>
            <div className="card-title">Recommended Resources</div>
            <div className="card-subtitle">Curated for your weak areas</div>
          </div>
          <Link to="/resources" className="btn btn-secondary btn-sm">All Resources</Link>
        </div>
        <div className="grid-3">
          {resources.map(r => (
            <div key={r._id} style={{
              border: '1px solid var(--color-border)',
              borderRadius: 'var(--radius-lg)',
              padding: 'var(--space-4)',
              transition: 'all 0.2s',
            }}
              onMouseEnter={e => e.currentTarget.style.boxShadow = 'var(--shadow-md)'}
              onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <span style={{ fontSize: '22px' }}>{typeIconMap[r.type] || '📚'}</span>
                <span className="badge badge-info" style={{ fontSize: '10px' }}>{r.type.toUpperCase()}</span>
              </div>
              <div style={{ fontSize: '13px', fontWeight: 600, marginBottom: '4px' }}>{r.title}</div>
              <div style={{ fontSize: '11px', color: 'var(--color-text-muted)', marginBottom: '8px' }}>{r.course?.name}</div>
              <div style={{ fontSize: '12px', color: 'var(--color-text-secondary)', marginBottom: '10px', lineHeight: 1.4 }}>{r.description}</div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '3px', fontSize: '12px', color: '#f59e0b' }}>
                  <FiStar size={12} fill="#f59e0b" /> {r.rating}
                </div>
                <a href={r.url} className="btn btn-primary btn-sm" style={{ fontSize: '11px', padding: '4px 10px' }}>
                  Open <FiExternalLink size={10} />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
