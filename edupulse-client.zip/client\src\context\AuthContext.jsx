import { createContext, useContext, useState, useEffect } from 'react';
import { DEMO_USERS, DEMO_NOTIFICATIONS } from '../data/mockData';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const stored = localStorage.getItem('edupulse_user');
    const storedToken = localStorage.getItem('edupulse_token');
    if (stored && storedToken) {
      const parsedUser = JSON.parse(stored);
      setUser(parsedUser);
      setToken(storedToken);
      loadNotifications(parsedUser);
    }
    setLoading(false);
  }, []);

  const loadNotifications = (u) => {
    const role = u.role;
    const notifs = DEMO_NOTIFICATIONS[role] || [];
    setNotifications(notifs);
  };

  const login = async (email, password) => {
    // Try demo users first (mock auth)
    const demoUser = Object.values(DEMO_USERS).find(
      u => u.email === email && u.password === password
    );
    
    if (demoUser) {
      const { password: _, ...userData } = demoUser;
      const fakeToken = `demo_token_${demoUser.role}_${Date.now()}`;
      setUser(userData);
      setToken(fakeToken);
      localStorage.setItem('edupulse_user', JSON.stringify(userData));
      localStorage.setItem('edupulse_token', fakeToken);
      loadNotifications(userData);
      return { success: true, user: userData };
    }

    // Try real backend
    try {
      const res = await fetch('http://localhost:5000/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        setToken(data.token);
        localStorage.setItem('edupulse_user', JSON.stringify(data.user));
        localStorage.setItem('edupulse_token', data.token);
        loadNotifications(data.user);
        return { success: true, user: data.user };
      }
    } catch {
      // Backend not available, use demo
    }
    
    return { success: false, message: 'Invalid credentials' };
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    setNotifications([]);
    localStorage.removeItem('edupulse_user');
    localStorage.removeItem('edupulse_token');
  };

  const markNotificationRead = (id) => {
    setNotifications(prev => prev.map(n => n._id === id ? { ...n, isRead: true } : n));
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <AuthContext.Provider value={{
      user, token, loading, login, logout,
      notifications, unreadCount, markNotificationRead, markAllRead,
      setNotifications,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
