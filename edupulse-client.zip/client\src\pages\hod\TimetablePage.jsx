import { useState } from 'react';
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const PERIODS = ['9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '1:00 PM (Lunch)', '2:00 PM', '3:00 PM', '4:00 PM'];

const TIMETABLE = {
  'III CSE - A': {
    Monday:    ['Data Structures', 'Data Structures', 'DBMS', 'DBMS', 'BREAK', 'OS', 'CN', 'Free'],
    Tuesday:   ['OS', 'CN', 'Data Structures Lab', 'Data Structures Lab', 'BREAK', 'DBMS', 'Free', 'Free'],
    Wednesday: ['CN', 'OS', 'DBMS', 'Free', 'BREAK', 'Data Structures', 'CN Lab', 'CN Lab'],
    Thursday:  ['DBMS', 'Data Structures', 'OS', 'CN', 'BREAK', 'Free', 'Free', 'Free'],
    Friday:    ['Data Structures', 'DBMS', 'CN', 'OS', 'BREAK', 'DBMS Lab', 'DBMS Lab', 'Free'],
    Saturday:  ['OS', 'CN', 'Free', 'Free', 'BREAK', 'Free', 'Free', 'Free'],
  },
};

const CLASS_COLORS = {
  'Data Structures': '#3b82f6',
  'DBMS': '#16a34a',
  'OS': '#7c3aed',
  'CN': '#f97316',
  'Data Structures Lab': '#0ea5e9',
  'DBMS Lab': '#22c55e',
  'CN Lab': '#fb923c',
  'Free': null,
  'BREAK': null,
};

export default function TimetablePage() {
  const [selectedClass, setSelectedClass] = useState('III CSE - A');
  const schedule = TIMETABLE[selectedClass] || {};

  return (
    <div className="animate-fade-in">
      <div className="page-header">
        <div className="page-header-row">
          <div>
            <div className="page-title">Timetable</div>
            <div className="page-subtitle">Weekly class schedule for {selectedClass}</div>
          </div>
          <select
            className="form-select" style={{ width: 'auto', minWidth: '160px' }}
            value={selectedClass} onChange={e => setSelectedClass(e.target.value)}
          >
            <option>III CSE - A</option>
            <option>III CSE - B</option>
            <option>II CSE - A</option>
            <option>I CSE - A</option>
            <option>IV CSE - A</option>
          </select>
        </div>
      </div>

      {/* Legend */}
      <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '20px' }}>
        {Object.entries(CLASS_COLORS).filter(([k, v]) => v).map(([subject, color]) => (
          <div key={subject} style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', fontWeight: 600 }}>
            <div style={{ width: 12, height: 12, borderRadius: '3px', background: color }} />
            {subject}
          </div>
        ))}
      </div>

      {/* Timetable Grid */}
      <div className="card" style={{ padding: 0, overflow: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '900px' }}>
          <thead>
            <tr style={{ background: 'var(--color-bg-secondary)' }}>
              <th style={{ padding: '14px 16px', textAlign: 'left', fontSize: '12px', fontWeight: 700, color: 'var(--color-text-muted)', textTransform: 'uppercase', borderBottom: '1px solid var(--color-border)', width: '90px' }}>Time</th>
              {DAYS.map(day => (
                <th key={day} style={{ padding: '14px 12px', textAlign: 'center', fontSize: '13px', fontWeight: 700, borderBottom: '1px solid var(--color-border)', color: 'var(--color-text-primary)' }}>
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {PERIODS.map((period, pi) => (
              <tr key={period} style={{ background: period.includes('Lunch') ? '#fffbeb' : 'white' }}>
                <td style={{ padding: '10px 16px', fontSize: '11px', fontWeight: 700, color: 'var(--color-text-muted)', borderBottom: '1px solid var(--color-border-light)', whiteSpace: 'nowrap' }}>
                  {period}
                </td>
                {DAYS.map(day => {
                  const subject = schedule[day]?.[pi] || '—';
                  const color = CLASS_COLORS[subject];
                  const isBreak = subject === 'BREAK';
                  const isFree = subject === 'Free';
                  return (
                    <td key={day} style={{ padding: '8px', borderBottom: '1px solid var(--color-border-light)', textAlign: 'center' }}>
                      {isBreak ? (
                        <div style={{ padding: '6px 10px', background: '#fffbeb', borderRadius: '8px', fontSize: '11px', color: '#f59e0b', fontWeight: 700 }}>
                          🍽️ Lunch
                        </div>
                      ) : isFree ? (
                        <div style={{ padding: '6px 10px', fontSize: '11px', color: 'var(--color-text-muted)' }}>—</div>
                      ) : color ? (
                        <div style={{
                          padding: '8px 10px', background: color + '15',
                          border: `1px solid ${color}40`, borderRadius: '8px',
                          fontSize: '12px', fontWeight: 700, color: color,
                        }}>
                          {subject}
                        </div>
                      ) : <span style={{ fontSize: '12px', color: 'var(--color-text-muted)' }}>—</span>}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
