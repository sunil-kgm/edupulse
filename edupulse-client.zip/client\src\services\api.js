import axios from 'axios';

const API_BASE = 'http://localhost:5000/api';

const api = axios.create({ baseURL: API_BASE });

// Attach token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('edupulse_token');
  if (token && !token.startsWith('demo_token_')) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// ── Auth ──────────────────────────────────
export const loginAPI = (email, password) =>
  api.post('/auth/login', { email, password });

// ── Users ─────────────────────────────────
export const getAllUsers = () => api.get('/users');
export const getUserById = (id) => api.get(`/users/${id}`);
export const createUser = (data) => api.post('/users', data);
export const updateUser = (id, data) => api.put(`/users/${id}`, data);
export const deleteUser = (id) => api.delete(`/users/${id}`);

// ── Courses ───────────────────────────────
export const getCourses = () => api.get('/courses');
export const getCourseById = (id) => api.get(`/courses/${id}`);
export const createCourse = (data) => api.post('/courses', data);

// ── Assignments ───────────────────────────
export const getAssignments = () => api.get('/assignments');
export const submitAssignment = (id, data) => api.post(`/assignments/${id}/submit`, data);

// ── Quizzes ───────────────────────────────
export const getQuizzes = () => api.get('/quizzes');
export const submitQuiz = (id, data) => api.post(`/quizzes/${id}/attempt`, data);

// ── Attendance ────────────────────────────
export const getAttendance = () => api.get('/attendance/my');
export const getStudentAttendance = (studentId) => api.get(`/attendance/student/${studentId}`);
export const markAttendance = (data) => api.post('/attendance', data);

// ── Risk ──────────────────────────────────
export const getRiskFlags = () => api.get('/risk/my');
export const getDeptRiskFlags = () => api.get('/risk/department');
export const triggerRiskDetection = (studentId) => api.post(`/risk/detect/${studentId}`);

// ── Recovery ──────────────────────────────
export const getRecoveryPath = () => api.get('/recovery/my');
export const updateMilestone = (recoveryId, milestoneId, data) =>
  api.put(`/recovery/${recoveryId}/milestone/${milestoneId}`, data);

// ── Faculty Reports ───────────────────────
export const getReports = () => api.get('/reports');
export const getMyReports = () => api.get('/reports/my');
export const createReport = (data) => api.post('/reports', data);
export const acknowledgeReport = (reportId) => api.put(`/reports/${reportId}/acknowledge`);
export const getReportsByStudent = (studentId) => api.get(`/reports/student/${studentId}`);

// ── Notifications ─────────────────────────
export const getNotifications = () => api.get('/notifications');
export const markNotifRead = (id) => api.put(`/notifications/${id}/read`);
export const markAllNotifsRead = () => api.put('/notifications/read-all');

// ── Analytics ─────────────────────────────
export const getDeptAnalytics = () => api.get('/analytics/department');
export const getStudentAnalytics = (studentId) => api.get(`/analytics/student/${studentId}`);
export const getAdminAnalytics = () => api.get('/analytics/admin');

// ── Resources ─────────────────────────────
export const getResources = () => api.get('/resources');

export default api;
