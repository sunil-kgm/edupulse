import { useState, useEffect } from 'react';
import { getAllUsers } from '../../services/api';
import { DEMO_USERS } from '../../data/mockData';
import { FiUser, FiMail, FiSearch, FiPlus, FiEdit, FiTrash2 } from 'react-icons/fi';

const DEMO_FACULTY_LIST = [
  { _id: 'f1', name: 'Dr. Priya Nair', email: 'faculty@edupulse.edu', department: { name: 'CSE' }, role: 'faculty', courses: 2, students: 62, status: 'active' },
  { _id: 'f2', name: 'Prof. Rajesh Iyer', email: 'faculty2@edupulse.edu', department: { name: 'CSE' }, role: 'faculty', courses: 2, students: 58, status: 'active' },
  { _id: 'f3', name: 'Dr. Anitha Krishnan', email: 'faculty3@edupulse.edu', department: { name: 'CSE' }, role: 'faculty', courses: 1, students: 60, status: 'active' },
  { _id: 'f4', name: 'Dr. Suresh Babu', email: 'faculty4@edupulse.edu', department: { name: 'CSE' }, role: 'faculty', courses: 2, students: 55, status: 'active' },
  { _id: 'f5', name: 'Mrs. Lakshmi Devi', email: 'faculty5@edupulse.edu', department: { name: 'CSE' }, role: 'faculty', courses: 1, students: 60, status: 'on-leave' },
];

export default function FacultyManagementPage() {
  const [faculty, setFaculty] = useState(DEMO_FACULTY_LIST);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await getAllUsers();
        const facultyList = res.data.filter(u => u.role === 'faculty');
        if (facultyList.length > 0) setFaculty(facultyList);
      } catch { /* use demo */ }
    };
    load();
  }, []);

  const filtered = faculty.filter(f =>
    f.name.toLowerCase().includes(search.toLowerCase()) ||
    f.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="animate-fade-in">
      <div className="page-header">
        <div className="page-header-row">
          <div>
            <div className="page-title">Faculty Management</div>
            <div className="page-subtitle">{faculty.length} faculty members in CSE Department</div>
          </div>
          <button className="btn btn-primary"><FiPlus size={14} /> Add Faculty</button>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '16px', marginBottom: '24px' }}>
        {[
          { label: 'Total Faculty', value: faculty.length, color: '#3b82f6', icon: '👨‍🏫' },
          { label: 'Active', value: faculty.filter(f => f.status === 'active').length, color: '#16a34a', icon: '✅' },
          { label: 'On Leave', value: faculty.filter(f => f.status === 'on-leave').length, color: '#f97316', icon: '🏖️' },
          { label: 'Total Courses', value: faculty.reduce((s, f) => s + (f.courses || 0), 0), color: '#7c3aed', icon: '📚' },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div style={{ fontSize: '28px', marginBottom: '8px' }}>{s.icon}</div>
            <div style={{ fontSize: '28px', fontWeight: 800, color: s.color, fontFamily: "'Space Grotesk',sans-serif" }}>{s.value}</div>
            <div style={{ fontSize: '13px', color: 'var(--color-text-muted)', marginTop: '4px' }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Search */}
      <div style={{ position: 'relative', marginBottom: '20px', maxWidth: '400px' }}>
        <FiSearch size={16} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: 'var(--color-text-muted)' }} />
        <input
          className="form-input"
          style={{ paddingLeft: '40px' }}
          placeholder="Search faculty by name or email..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="table-container" style={{ border: 'none' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Faculty Member</th>
                <th>Email</th>
                <th>Courses</th>
                <th>Students</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(f => (
                <tr key={f._id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <div className="avatar avatar-sm" style={{ background: '#eff6ff', color: '#3b82f6', fontWeight: 700 }}>
                        {f.name[0]}
                      </div>
                      <div style={{ fontWeight: 600 }}>{f.name}</div>
                    </div>
                  </td>
                  <td style={{ color: 'var(--color-text-muted)', fontSize: '13px' }}>{f.email}</td>
                  <td><span className="badge badge-info">{f.courses || 0} Courses</span></td>
                  <td style={{ fontWeight: 600 }}>{f.students || 0}</td>
                  <td>
                    <span className={`badge ${f.status === 'active' ? 'badge-success' : 'badge-warning'}`}>
                      {f.status === 'active' ? '● Active' : '● On Leave'}
                    </span>
                  </td>
                  <td>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <button className="btn btn-secondary btn-sm"><FiEdit size={12} /> Edit</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
